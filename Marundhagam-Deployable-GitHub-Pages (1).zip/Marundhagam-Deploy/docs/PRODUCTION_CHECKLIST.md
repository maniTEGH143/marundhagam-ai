# Production checklist

1. Replace demo medicine records with authoritative reviewed sources.
2. Build a brand → generic → active-ingredient normalization table.
3. Add real OCR with confidence scores and user confirmation.
4. Add reviewed drug-interaction evidence and rule IDs.
5. Add a retrieval layer and context-only AI explanation.
6. Attach source/evidence/review metadata to every material answer.
7. Add automated regression tests for duplicate and interaction cases.
8. Add audit logs and database versioning.
9. Perform medical/pharmacist review before real-world use.
10. Deploy only after privacy, security, consent and applicable regulatory requirements are assessed.
